//
// Created by gconrad on 2/27/20.
//

#include <iostream>
#include "tests.h"
#include "production.h"

tests::tests() {
    std::cout << "Running tests..." << std::endl;
    didPass = testCountMoves();
    didPass = testPlayFirstMove() && didPass;
    std::cout << "Running tests finished." << std::endl;
}

bool tests::testCountMoves() {
    std::cout << "  testCountMoves: " << std::flush;
    bool pass = true;
    int board[SIZE][SIZE] = {
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, -1, 0, 0, 0, 0},
    };
    pass = production::countMoves(board, false) == 2 && pass;
    board[7][1] = -1;
    pass = production::countMoves(board, false) == 4 && pass;
    board[6][2] = 1;
    pass = production::countMoves(board, false) == 4 && pass;
    pass = production::countMoves(board, true) == 0 && pass;
    board[0][0] = 2;
    pass = production::countMoves(board, true) == 1 && pass;
    board[2][2] = 2;
    pass = production::countMoves(board, true) == 5 && pass;
    std::cout << (pass ? "pass" : "fail") << std::endl;
    return pass;
}

bool tests::testPlayFirstMove() {
    std::cout << "  testPlayFirstMove: " << std::flush;
    bool pass = true;
    int board[SIZE][SIZE] = {
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 1, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, -2, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0},
    };
    production::playFirstMove(board, true);
    pass = board[1][2] == 0 && board[2][1] == 1 && pass;
    production::playFirstMove(board, false);
    pass = board[5][5] == 0 && board[4][4] == -2 && pass;
    std::cout << (pass ? "pass" : "fail") << std::endl;
    return pass;
}
