//
// Created by gconrad on 2/27/20.
//

#ifndef SYSTEMSHW5_TESTS_H
#define SYSTEMSHW5_TESTS_H


class tests {
    bool didPass = true;
public:
    tests();

    static bool testCountMoves();

    static bool testPlayFirstMove();

    bool passed() { return didPass; }
};


#endif //SYSTEMSHW5_TESTS_H
