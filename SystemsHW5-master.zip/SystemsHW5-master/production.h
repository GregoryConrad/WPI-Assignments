//
// Created by gconrad on 2/27/20.
//

#ifndef SYSTEMSHW5_PRODUCTION_H
#define SYSTEMSHW5_PRODUCTION_H

#define SIZE 8

class production {
public:
    production(int argc, char *argv[]);

    static int countMoves(int board[SIZE][SIZE], bool posPlaying);

    static void playFirstMove(int (&board)[SIZE][SIZE], bool posPlaying);

    static void printBoard(int board[SIZE][SIZE], std::ofstream &file);
};


#endif //SYSTEMSHW5_PRODUCTION_H
