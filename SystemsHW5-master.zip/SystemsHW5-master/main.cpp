#include <iostream>
#include "tests.h"
#include "production.h"

int main(int argc, char *argv[]) {
    if (tests().passed()) {
        std::cout << "Tests passed. Running production..." << std::endl;
        production(argc, argv);
    }
    return 0;
}
