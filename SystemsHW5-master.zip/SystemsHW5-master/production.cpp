//
// Created by gconrad on 2/27/20.
//

#include <fstream>
#include <iostream>
#include "production.h"

production::production(int argc, char *argv[]) {
    // read board in from file
    int board[SIZE][SIZE] = {{0}};
    std::string inputFilename;
    if (argc >= 2)  {
        inputFilename = argv[1];
    } else {
        std::cout << "Enter the input checker grid's file name: ";
        std::cin >> inputFilename;
    }
    std::ifstream input;
    input.open(inputFilename);
    if (!input.is_open()) {
        std::cout << "Failed to open the input file." << std::endl;
        return;
    }
    for (int r = 0; r < SIZE; ++r) {
        for (int c = 0; c < SIZE; ++c) {
            input >> board[r][c];
        }
    }

    // ask which player is playing
    bool posPlaying;
    std::cout << "Enter 1 for positive to play first, 0 for negative to play first: ";
    std::cin >> posPlaying;

    // open output file
    std::ofstream output;
    output.open("output.txt");
    if (!output.is_open()) {
        std::cout << "Failed to open the output file." << std::endl;
        return;
    }

    // print the initial board
    std::cout << "Initial Board" << std::endl;
    printBoard(board, output);

    // count moves
    int totalMoves = countMoves(board, posPlaying);
    std::cout << "Playable moves: " << totalMoves << std::endl;
    output << totalMoves << std::endl;

    // play a move
    playFirstMove(board, posPlaying);
    std::cout << "Final Board" << std::endl;
    printBoard(board, output);
    output.close();
}

void production::printBoard(int board[SIZE][SIZE], std::ofstream &file) {
    for (int r = 0; r < SIZE; ++r) {
        for (int c = 0; c < SIZE; ++c) {
            std::cout << board[r][c] << " ";
            file << board[r][c] << " ";
        }
        std::cout << std::endl;
        file << std::endl;
    }
}

int production::countMoves(int board[SIZE][SIZE], bool posPlaying) {
    int count = 0;
    for (int r = 0; r < SIZE; ++r) {
        for (int c = 0; c < SIZE; ++c) {
            int val = board[r][c];
            if ((posPlaying && val <= 0) || (!posPlaying && val >= 0)) continue;
            for (int dRow = ((val == 1) ? 1 : -1); dRow <= ((val == -1) ? -1 : 1); dRow += 2) {
                for (int dCol = -1; dCol <= 1; dCol += 2) {
                    int newR = r + dRow, newC = c + dCol;
                    if (newR < 0 || newR >= SIZE || newC < 0 || newC >= SIZE) continue; // out of bounds
                    int neighbor = board[newR][newC];
                    // Neighbor same sign: no move
                    // Neighbor 0: possible move
                    // Neighbor opposite sign: check for capture by going one more in same direction
                    if (neighbor == 0) ++count;
                    else if ((val > 0 && neighbor < 0) || (val < 0 && neighbor > 0)) {
                        newR += dRow;
                        newC += dCol;
                        if (newR < 0 || newR >= SIZE || newC < 0 || newC >= SIZE) continue; // out of bounds
                        if (board[newR][newC] == 0) ++count;
                    }
                }
            }
        }
    }
    return count;
}

void production::playFirstMove(int (&board)[SIZE][SIZE], bool posPlaying) {
    for (int r = 0; r < SIZE; ++r) {
        for (int c = 0; c < SIZE; ++c) {
            int &val = board[r][c];
            if ((posPlaying && val <= 0) || (!posPlaying && val >= 0)) continue;
            for (int dRow = ((val == 1) ? 1 : -1); dRow <= ((val == -1) ? -1 : 1); dRow += 2) {
                for (int dCol = -1; dCol <= 1; dCol += 2) {
                    int newR = r + dRow, newC = c + dCol;
                    if (newR < 0 || newR >= SIZE || newC < 0 || newC >= SIZE) continue; // out of bounds
                    int &neighbor = board[newR][newC];
                    // Neighbor same sign: no move
                    // Neighbor 0: possible move
                    // Neighbor opposite sign: check for capture by going one more in same direction
                    if (neighbor == 0) {
                        neighbor = val;
                        val = 0;
                        return;
                    }
                    else if ((val > 0 && neighbor < 0) || (val < 0 && neighbor > 0)) {
                        newR += dRow;
                        newC += dCol;
                        if (newR < 0 || newR >= SIZE || newC < 0 || newC >= SIZE) continue; // out of bounds
                        if (board[newR][newC] == 0) {
                            neighbor = val;
                            val = 0;
                            return;
                        }
                    }
                }
            }
        }
    }
}
