//
// Created by Archie Milligan on 2/2/20.
//

#include <stdio.h>

/**
 * Helper method for print
 */
static void _printSeparatorLine() {
    printf("+");
    for (int i = 0; i < 20; ++i) printf("-+");
    printf("\n");
}

/**
 * Prints board in a user-friendly way
 */
void print(const int* board) {
    _printSeparatorLine();
    for (int row = 0; row < 20; ++row) {
        printf("|");
        for (int col = 0; col < 20; ++col) printf("%d|", *(board + 20*col + row));
        printf("\n");
        _printSeparatorLine();
    }
}