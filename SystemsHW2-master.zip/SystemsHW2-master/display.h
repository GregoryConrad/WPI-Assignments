//
// Created by Archie Milligan on 2/2/20.
//

#ifndef SYSTEMSHW2_DISPLAY_H
#define SYSTEMSHW2_DISPLAY_H

void print(int* board);

#endif //SYSTEMSHW2_DISPLAY_H
