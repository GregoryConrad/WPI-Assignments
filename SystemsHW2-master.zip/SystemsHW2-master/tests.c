/*
 * tests.c
 *
 *  Created on: Jul 4, 2019
 *      Author: Therese
 */

#include "tests.h"
#include "production.h"

bool tests() {
    printf("Running tests:\n");
    bool answer;
    bool ok1 = testMoveMarker();
    bool ok2 = testPlaceMarker();
    answer = ok1 && ok2;
    printf("%s\n", answer ? "All tests passed" : "1 or more tests failed");
    return answer;
}

bool testPlaceMarker() {
    printf("Testing placeMarker...\n");
    bool ok = false;
    Marker *m = placeMarker(0, 0);
    ok = m->row == 0 && m->col == 0;
    free(m);
    m = placeMarker(-1, 1);
    ok = ok && m->row == -1 && m->col == 1;
    free(m);
    printf("  status: %s\n", ok ? "pass" : "fail");
    return ok;
}

/**
 * A helper for testMoveMarker()
 * @param m1 first marker to compare
 * @param m2 second marker to compare
 * @return whether the markers are equivalent (true) or not (false)
 */
bool compareMarkers(Marker *m1, Marker *m2) {
    return m1->row == m2->row && m1->col == m2->col;
}

bool testMoveMarker() {
    printf("Testing moveMarker...\n");
    bool answer = false;
    int *testBoard = malloc(20 * 20 * sizeof(int));
    initSpace(testBoard, 20);

    Marker *testMarker = placeMarker(0, 0);
    Marker *northMarker = placeMarker(19, 0);
    Marker *southMarker = placeMarker(1, 0);
    Marker *eastMarker = placeMarker(0, 1);
    Marker *westMarker = placeMarker(0, 19);

    //test case 1:
    bool ok0 = compareMarkers(moveMarker(testMarker, 0, testBoard), northMarker);
    //test case 2:
    bool ok1 = compareMarkers(moveMarker(testMarker, 1, testBoard), southMarker);
    //test case
    bool ok2 = compareMarkers(moveMarker(testMarker, 2, testBoard), westMarker);
    //test case 4:
    bool ok3 = compareMarkers(moveMarker(testMarker, 3, testBoard), eastMarker);
    answer = ok0 && ok1 && ok2 && ok3;
    printf("  status: %s\n", answer ? "pass" : "fail");
    return answer;
}
