/*
 * marker.h
 *
 *  Created on: Jan 27, 2020
 *      Author: Therese
 */

#ifndef MARKER_H_
#define MARKER_H_
#include <stdio.h>

typedef struct {
    int index;
    int row;
    int col;
} Marker;

Marker *placeMarker(int, int);

Marker *moveMarker(Marker *oldMarker, int direction, int *board);

#endif /* MARKER_H_ */
