/*
 * marker.c
 *
 *  Created on: Jan 27, 2020
 *      Author: Therese
 */

#include <stdlib.h>
#include "marker.h"

Marker *placeMarker(int r, int c) {
    Marker *mP = (Marker *) malloc(sizeof(Marker));
    mP->row = r;
    mP->col = c;
    return mP;
}

Marker *moveMarker(Marker *oldMarker, int direction, int *board) {
    Marker *m = placeMarker(oldMarker->row, oldMarker->col);
    m->index = oldMarker->index + 1;
    switch (direction) {
        case 0:
            if (--m->row < 0) m->row = 20 - 1;
            break;
        case 1:
            if (++m->row >= 20) m->row = 0;
            break;
        case 2:
            if (--m->col < 0) m->col = 20 - 1;
            break;
        case 3:
            if (++m->col >= 20) m->col = 0;
            break;
        default:
            printf("Invalid direction provided to moveMarker\n");
            return NULL;
    }
    *(board + m->col * 20 + m->row) = m->index % 10;
    return m;
}