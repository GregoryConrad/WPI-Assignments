//
// Created by Gregory Conrad on 1/23/20.
// gsconrad@wpi.edu

#ifndef SYSTEMSHW1_GREGORY_CONRAD_H
#define SYSTEMSHW1_GREGORY_CONRAD_H

#include "Search.h"
#include "House.h"
#include "Layout.h"
#include "Room.h"

// Any function/variable declarations would go here

#endif //SYSTEMSHW1_GREGORY_CONRAD_H
