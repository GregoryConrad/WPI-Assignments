//
// Created by gconrad on 1/22/20.
//

#ifndef SYSTEMSHW1_ROOM_H
#define SYSTEMSHW1_ROOM_H

#include <stdbool.h>

typedef struct Room {
    bool isOpen, treasure;
} Room;

#endif //SYSTEMSHW1_ROOM_H
