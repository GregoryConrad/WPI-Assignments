//
// Created by gconrad on 1/22/20.
//

#ifndef SYSTEMSHW1_LAYOUT_H
#define SYSTEMSHW1_LAYOUT_H

#include "Room.h"

typedef struct Layout {
    Room firstRoom;
    int nRooms;
} Layout;

bool open(Room room);

#endif //SYSTEMSHW1_LAYOUT_H
