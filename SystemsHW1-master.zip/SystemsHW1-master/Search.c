//
// Created by gconrad on 1/22/20.
//

#include "Search.h"
#include "House.h"

int getNumberOfRooms(House house) { return countRooms(house.floorPlan); }

Room getNewRoom(House house) { return getFirstRoom(house.floorPlan); }

bool haveTreasure(Room room) { return room.treasure; }
