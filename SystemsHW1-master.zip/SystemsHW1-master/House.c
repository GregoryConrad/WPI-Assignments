//
// Created by gconrad on 1/22/20.
//

#include "House.h"

int countRooms(Layout layout) {
    return layout.nRooms;
}

Room getFirstRoom(Layout layout) {
    return layout.firstRoom;
}
