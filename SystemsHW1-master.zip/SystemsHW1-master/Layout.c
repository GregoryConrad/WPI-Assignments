//
// Created by Archie Milligan on 1/22/20.
//

#include "Layout.h"

bool open(Room room) {
    return room.isOpen = true;
}