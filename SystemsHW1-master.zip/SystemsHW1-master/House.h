//
// Created by gconrad on 1/22/20.
//

#ifndef SYSTEMSHW1_HOUSE_H
#define SYSTEMSHW1_HOUSE_H

#include "Layout.h"

typedef struct House {
    int squareFootage;
    int numberOfBathrooms;
    int numberOfOtherRooms;
    int numberOfBedrooms;

    Layout floorPlan;
} House;

int countRooms(Layout floorPlan);

Room getFirstRoom(Layout floorPlan);

#endif //SYSTEMSHW1_HOUSE_H
