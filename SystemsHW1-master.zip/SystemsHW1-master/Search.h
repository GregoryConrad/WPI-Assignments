//
// Created by gconrad on 1/22/20.
//

#ifndef SYSTEMSHW1_SEARCH_H
#define SYSTEMSHW1_SEARCH_H

#include "House.h"
#include "Room.h"

int getNumberOfRooms(House house);

Room getNewRoom(House house);

bool haveTreasure(Room room);

#endif //SYSTEMSHW1_SEARCH_H
