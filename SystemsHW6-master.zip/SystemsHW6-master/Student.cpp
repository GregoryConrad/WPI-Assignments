/*
 * Student.cpp
 *
 *  Created on: Feb 21, 2020
 *      Author: michaelengling
 */

#include "Student.h"

std::ostream &operator<<(std::ostream &os, const Student &s) {
    os << s.first_ << " " << s.last_ << ", ID: " << s.id_
       << ", GPA: " << std::fixed << std::setprecision(2) << s.gpa_;
    return os;
}

string Student::getFirst() { return first_; }

string Student::getLast() { return last_; }

float Student::getGPA() { return gpa_; }

int Student::getID() { return id_; }

void Student::setGPA(float f) { gpa_ = f; }

void Student::setID(int i) { id_ = i; }