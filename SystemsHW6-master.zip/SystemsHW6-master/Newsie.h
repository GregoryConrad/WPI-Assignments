//
// Created by Archie Milligan on 3/1/20.
//

#ifndef SYSTEMSHW6_NEWSIE_H
#define SYSTEMSHW6_NEWSIE_H

#include "Student.h"

enum article {
    News,
    Opinions_n_Editorials,
    Features,
    Sports,
    Entertainment,
    Humor,
    NONE
};

enum position {
    Editor,
    Deputy_Editor,
    Assistant_Editor,
    Reporter,
    Cub_Reporter
};

struct assignment {
    article desk;//New desk, sports desk, etc.
    string temptitle; //working title of piece to be written
    bool assigned; //default to false; true only once assigned to writer
    string worker;
    friend std::ostream &operator<<(std::ostream &os, const assignment &a);
    explicit operator string() const;

    assignment() : desk(NONE), temptitle(""), assigned(false), worker("") {}
};

class Newsie : public Student {
private:
    position title_;

    article primary_;
    article secondary_;
    article tertiary_;

    int term_goal_;
    int term_kount_;
    int terms_;

    string non_de_plume_;

    assignment current_priority_;
    assignment current_extra_;
    assignment current_emergency_;
public:
    Newsie(const string &firstName, const string &lastName, float gpa, int id, position title, article primary,
           article secondary, article tertiary, int termGoal, int termKount, int terms, string nonDePlume);

    friend std::ostream &operator<<(std::ostream &os, const Newsie &n);

    [[nodiscard]] article getPrimary() const;

    [[nodiscard]] article getSecondary() const;

    [[nodiscard]] article getTertiary() const;

    [[nodiscard]] int getTermGoal() const;

    [[nodiscard]] int getTermKount() const;

    void setTermKount(int termKount);

    [[nodiscard]] const assignment &getCurrentPriority() const;

    void setCurrentPriority(const assignment &currentPriority);

    [[nodiscard]] const assignment &getCurrentExtra() const;

    void setCurrentExtra(const assignment &currentExtra);

    [[nodiscard]] const assignment &getCurrentEmergency() const;

    void setCurrentEmergency(const assignment &currentEmergency);
};

#endif //SYSTEMSHW6_NEWSIE_H
