/*
 * Student.h
 *
 *  Created on: Feb 21, 2020
 *      Author: michaelengling
 */

#ifndef STUDENT_H_
#define STUDENT_H_

#include <string>
#include <iostream>
#include <iomanip>
#include <utility>

using std::string;

class Student {
protected:
    string first_;
    string last_;
    float gpa_;
    int id_;
public:
    Student(string first_name, string last_name, float gpa, int id) :
            first_(std::move(first_name)), last_(std::move(last_name)), gpa_(gpa), id_(id) {}

    friend std::ostream &operator<<(std::ostream &os, const Student &s);

    string getFirst();

    string getLast();

    float getGPA();

    int getID();

    void setGPA(float f);

    void setID(int i);
};

#endif /* STUDENT_H_ */
