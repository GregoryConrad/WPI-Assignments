//============================================================================
// Name        : Newsie.cpp
// Author      : me
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

/*
 ============================================================================
 Name        : Newsies Tester.c
 Author      : me
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */


#include "Newsie.h"
#include <utility>
#include <sstream>>

assignment::operator string() const {
    std::ostringstream os;

    switch (desk) {
        case News:
            os << "(News) ";
            break;
        case Opinions_n_Editorials:
            os << "(Opinions And Editorials) ";
            break;
        case Features:
            os << "(Features) ";
            break;
        case Sports:
            os << "(Sports) ";
            break;
        case Entertainment:
            os << "(Entertainment) ";
            break;
        case Humor:
            os << "(Humor) ";
            break;
        case NONE:
            os << "NOT ASSIGNED";
            break;
    }
    os << temptitle << std::endl;
    os << "\t\t" << (assigned ? "Assigned to: ": "") << worker << std::endl;
    return os.str();
}

std::ostream &operator << (std::ostream &os, const assignment &a) {
    os << a.operator string();
    return os;
}

std::ostream &operator << (std::ostream &os, const Newsie &n) {
    os << "Name: " << n.first_ << " '" << n.non_de_plume_ << "' " << n.last_ ;
    switch (n.title_) {
        case Editor:
            os << ": Editor";
            break;
        case Deputy_Editor:
            os << ": Deputy Editor";
            break;
        case Assistant_Editor:
            os << ": Assistant Editor";
            break;
        case Reporter:
            os << ": Reporter";
            break;
        case Cub_Reporter:
            os << ": Cub Reporter";
            break;
    }
    os << std::endl << "\tArticles: " << std::endl;
    const auto na = "NOT ASSIGNED";
    os << "\t" << (n.current_priority_.assigned ? "Current Priority: " : "")<< n.current_priority_
       << "\t" << (n.current_extra_.assigned ? "Current Extra: " : "") << n.current_extra_
       << "\t" << (n.current_emergency_.assigned ? "Current Emergency: " : "")<< n.current_emergency_;
    const int numOfArticles = 3;
    const article articles[numOfArticles] = {n.primary_, n.secondary_, n.tertiary_};
    for (int i = 0; i < numOfArticles; ++i) {
        switch (i) {
            case 0:
                os << "\tPrimary: ";
                break;
            case 1:
                os << "\tSecondary: ";
                break;
            case 2:
                os << "\tTertiary: ";
                break;
            default:
                throw "Incorrect number of articles";
        }
        switch (articles[i]) {
            case News:
                os << "News ";
                break;
            case Opinions_n_Editorials:
                os << "Opinions And Editorials ";
                break;
            case Features:
                os << "Features ";
                break;
            case Sports:
                os << "Sports ";
                break;
            case Entertainment:
                os << "Entertainment ";
                break;
            case Humor:
                os << "Humor ";
                break;
            case NONE:
                os << "NONE";
                break;
        }
        os << std::endl;
    }
    os
        << "\tID: " << n.id_ << " \tGPA: " << n.gpa_ << std::endl
        << "\tTerm Goal: " << n.term_goal_
        << "\tTerm Kount: " << n.term_kount_
        << "\tTerms: " << n.terms_ << std::endl;
        //Non de Plume is part of name according to assignment sheet
    return os;
}

Newsie::Newsie(const string &firstName, const string &lastName, float gpa, int id, position title, article primary,
               article secondary, article tertiary, int termGoal, int termKount, int terms, string nonDePlume)
        : Student(firstName, lastName, gpa, id), title_(title), primary_(primary), secondary_(secondary),
          tertiary_(tertiary), term_goal_(termGoal), term_kount_(termKount), terms_(terms),
          non_de_plume_(std::move(nonDePlume)), current_priority_(assignment()), current_extra_(assignment()),
          current_emergency_(assignment()) {}

article Newsie::getPrimary() const {
    return primary_;
}

article Newsie::getSecondary() const {
    return secondary_;
}

article Newsie::getTertiary() const {
    return tertiary_;
}

int Newsie::getTermGoal() const {
    return term_goal_;
}

int Newsie::getTermKount() const {
    return term_kount_;
}

void Newsie::setTermKount(int termKount) {
    term_kount_ = termKount;
}

const assignment &Newsie::getCurrentPriority() const {
    return current_priority_;
}

void Newsie::setCurrentPriority(const assignment &currentPriority) {
    current_priority_ = currentPriority;
}

const assignment &Newsie::getCurrentExtra() const {
    return current_extra_;
}

void Newsie::setCurrentExtra(const assignment &currentExtra) {
    current_extra_ = currentExtra;
}

const assignment &Newsie::getCurrentEmergency() const {
    return current_emergency_;
}

void Newsie::setCurrentEmergency(const assignment &currentEmergency) {
    current_emergency_ = currentEmergency;
}
