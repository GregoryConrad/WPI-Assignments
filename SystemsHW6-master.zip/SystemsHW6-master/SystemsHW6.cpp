//
// Created by Archie Milligan on 3/1/20.
//


#include <vector>
#include <fstream>
#include "Newsie.h"

using std::cout;

void print(const std::vector<assignment> &assignments) {
    cout << "\nAssignments:" << std::endl;
    for (const auto &a: assignments) cout << a;
}

void print(const std::vector<Newsie> &n) {
    cout << "\nNewsies:" << std::endl;
    for (const auto &s : n) cout << s << std::endl;
}

void print_weekly_rollcall(std::vector<Newsie> all_writers){
    print(all_writers);
}

void print_weekly_assignment_desk(std::vector<assignment> all_assignments){
    print(all_assignments);
}



void appendNewsies(std::vector<Newsie> &students, std::vector<assignment> &assignments) {
    std::ifstream newies("NewsiesStaff.txt");
    if (!newies.is_open()) {
        printf("Can't find file");
        return;
    }
    cout << "\n\nreading NewsiesStaff.txt";
    int sentinel = 0;
    newies >> sentinel;
    //printf("\nNewsie Staff Info\n");
    for (int kount = 1; kount <= sentinel; kount++) {
        string first, last;
        float gpa;
        int id;
        int title;
        int primary, secondary, tertiary;
        int term_goal, term_kount, terms;
        string non_de_plume;
        newies >> first >> last >> gpa >> id >> title >> primary >> secondary >> tertiary >> term_goal >> term_kount
               >> terms >> non_de_plume;
        students.emplace_back(Newsie(first, last, gpa, id, (position) title, (article) primary, (article) secondary,
                                     (article) tertiary, term_goal, term_kount, terms, non_de_plume));
    }
    newies.close();
    cout << "\n\nSuccessfully read NewsiesStaff.txt";

    std::ifstream assignmentEditor("AssignmentEditorTxt.txt");
    if (!assignmentEditor.is_open()) {
        printf("Can't find file");
        return;
    }
    cout << "\n\nreading AssignmentEditorTxt.txt";
    assignmentEditor >> sentinel;
    for (int kount = 1; kount <= sentinel; kount++) {
        int desk;
        assignment tempAssignment;
        assignmentEditor >> desk >> tempAssignment.temptitle;
        tempAssignment.desk = (article) desk;
        assignments.emplace_back(tempAssignment);
    }
    assignmentEditor.close();
    cout << "\n\nSuccessfully read AssignmentEditorTxt.txt\n\n";
}

void assignArticles(std::vector<Newsie> &newsies, std::vector<assignment> &assignments) {
    //assign articles based upon need to meet term goals
    for (auto &n: newsies) {
        if (n.getTermGoal() > n.getTermKount()) {
            for (auto &a: assignments) {
                if (!a.assigned) {
                    if (a.desk == n.getPrimary() || a.desk == n.getSecondary() || a.desk == n.getTertiary()) {
                        int delta = n.getTermGoal() - n.getTermKount();
                        if (delta > 0) {
                            if (n.getCurrentPriority().desk == NONE) {
                                a.worker = n.getLast();
                                a.assigned = true;
                                n.setCurrentPriority(a);
                                n.setTermKount(n.getTermKount() + 1);
                            } else if (n.getCurrentExtra().desk == NONE) {
                                a.worker = n.getLast();
                                a.assigned = true;
                                n.setCurrentExtra(a);
                                n.setTermKount(n.getTermKount() + 1);
                            } else if (n.getCurrentEmergency().desk == NONE) {
                                a.worker = n.getLast();
                                a.assigned = true;
                                n.setCurrentEmergency(a);
                                n.setTermKount(n.getTermKount() + 1);
                            }
                        }
                    }
                }
            }
        }
    }

    //assign rest of articles now purely based upon who can take them
    for (auto &n: newsies) {
        for (auto &a: assignments) {
            if (!a.assigned) {
                if (a.desk == n.getPrimary() || a.desk == n.getSecondary() || a.desk == n.getTertiary()) {
                    if (n.getCurrentPriority().desk == NONE) {
                        a.worker = n.getLast();
                        a.assigned = true;
                        n.setCurrentPriority(a);
                        n.setTermKount(n.getTermKount() + 1);
                    } else if (n.getCurrentExtra().desk == NONE) {
                        a.worker = n.getLast();
                        a.assigned = true;
                        n.setCurrentExtra(a);
                        n.setTermKount(n.getTermKount() + 1);
                    } else if (n.getCurrentEmergency().desk == NONE) {
                        a.worker = n.getLast();
                        a.assigned = true;
                        n.setCurrentEmergency(a);
                        n.setTermKount(n.getTermKount() + 1);
                    }
                }
            }
        }
    }
}

int main() {
    std::vector<Newsie> students;
    std::vector<assignment> assignments;
    appendNewsies(students, assignments);
    assignArticles(students, assignments);
    print_weekly_rollcall(students);
    print_weekly_assignment_desk(assignments);


    return EXIT_SUCCESS;
}