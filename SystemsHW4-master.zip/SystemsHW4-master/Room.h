//
// Created by gconrad on 2/19/20.
//

#ifndef SYSTEMSHW4_ROOM_H
#define SYSTEMSHW4_ROOM_H

struct Room {
    Room(int roomNumber, float treasure) : roomNumber(roomNumber), treasure(treasure), searched(false) {}

    int roomNumber;
    float treasure;
    bool searched;
};

#endif //SYSTEMSHW4_ROOM_H
