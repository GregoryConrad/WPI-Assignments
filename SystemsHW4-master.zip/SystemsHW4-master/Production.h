/*
 * Production.h
 *
 *  Created on: Feb 1, 2020
 *      Author: Therese
 */

#ifndef PRODUCTION_H_
#define PRODUCTION_H_

#include <vector>
#include "AdjMat.h"
#include "Room.h"

#define FILENAMELENGTHALLOWANCE 50

class Production {
public:
    bool prod(int argc, char *argv[]);

    static bool readFile(char *filename, AdjMat &adjMat, std::vector<Room> &rooms);
};

#endif /* PRODUCTION_H_ */
