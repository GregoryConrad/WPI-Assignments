/*
 * Tests.cpp
 *
 *  Created on: Feb 1, 2020
 *      Author: Therese
 */

#include <iostream>
#include <vector>
#include "Tests.h"
#include "Room.h"
#include "AdjMat.h"
#include "Production.h"

bool Tests::tests() {
    bool result1 = testAdjacencyMatrix();
    bool result2 = testReadFile();
    return result1 && result2;
}

bool Tests::testReadFile() {
    std::cout << "starting testReadFile..." << std::endl;
    bool ok = false;
    //the file tells how many rooms there are
    const int rightAnswer = 8;
    AdjMat adjMat(0, nullptr);
    std::vector<Room> rooms;
    ok = Production::readFile("houseGraph.txt", adjMat, rooms); //read the file
    if (ok) {
        if (rooms.size() != rightAnswer) {
            puts("test failed on number of rooms");
        }
    }
    puts("The adjacency matrix");
    for (int i = 0; i < rooms.size(); i++) {
        for (int j = 0; j < rooms.size(); j++) {
            printf("%d", adjMat.getEdge(i, j));
        }
        printf("\n");
    }
    puts("The treasure values");
    for (auto room : rooms) {
        printf("%f\n", room.treasure);
    }
    std::cout << "testReadFile: " << (ok ? "pass" : "fail") << std::endl;
    return ok;
}

bool Tests::testAdjacencyMatrix() {
    std::cout << "starting testAdjacencyMatrix..." << std::endl;
    bool ans = true;
    AdjMat adjMat(2, new int[2 * 2]);
    adjMat.setEdge(0, 1);
    bool answer = adjMat.getEdge(0, 1) && adjMat.getEdge(1, 0) &&
                  !adjMat.getEdge(0, 0) && !adjMat.getEdge(1, 1);
    std::cout << "testAdjacencyMatrix: " << (answer ? "pass" : "fail") << std::endl;
    return answer;
}