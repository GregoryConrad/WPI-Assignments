//
// Created by gconrad on 2/19/20.
//

#ifndef SYSTEMSHW4_ADJMAT_H
#define SYSTEMSHW4_ADJMAT_H

class AdjMat {
private:
    int n;
    int *edgesP;
public:
    AdjMat(int n, int *edgesP);

    void setEdge(int row, int col);

    int getEdge(int row, int col);
};

#endif //SYSTEMSHW4_ADJMAT_H
