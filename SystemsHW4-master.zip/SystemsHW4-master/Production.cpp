/*
 * Production.cpp
 *
 *  Created on: Feb 1, 2020
 *      Author: Therese
 */

#include <iostream>
#include <cstring>
#include <queue>
#include <fstream>
#include "Production.h"

struct SearchResults {
    SearchResults(int roomNumber, float treasure) : roomNumber(roomNumber), treasure(treasure) {}

    int roomNumber;
    float treasure;
};

bool Production::prod(int argc, char *argv[]) {
    bool answer = false;

    if (argc <= 1) //no interesting information
    {
        std::cout << "Didn't find any arguments." << std::endl;
        answer = false;
    } else //there is interesting information
    {
        printf("Found %d interesting arguments.\n", argc - 1);
        fflush(stdout);
        char filename[FILENAMELENGTHALLOWANCE];
        char *eptr = (char *) malloc(sizeof(char *));
        long aL = -1L;
        int maxRooms = -1;
        float maxTreasure = -1;
        double maxTreas;
        for (int i = 1; i < argc; i++) //don't want to read argv[0]
        {//argv[i] is a string
            //in this program our arguments are NR, NC, gens, filename, print and pause
            //because pause is optional, argc could be 6 or 7
            //because print is optional (if print is not present, neither is pause) argc could be 5
            switch (i) {
                case 1:
                    //this is filename
                    printf("The length of the filename is %zu.\n", strlen(argv[i]));
                    printf("The proposed filename is %s.\n", argv[i]);
                    if (strlen(argv[i]) >= FILENAMELENGTHALLOWANCE) {
                        puts("Filename is too long.");
                        fflush(stdout);
                        answer = false;
                    } else {
                        strcpy(filename, argv[i]);
                        printf("Filename was %s.\n", filename);
                        fflush(stdout);
                    }
                    break;
                case 2:
                    //this is maximum number of rooms

                    aL = strtol(argv[i], &eptr, 10);
                    maxRooms = (int) aL;
                    printf("Number of rooms is %d\n", maxRooms);
                    fflush(stdout);
                    break;
                case 3:
                    //this is maximum amount of treasure

                    maxTreas = atof(argv[i]);
                    printf("Amount of  treasure is %f\n", maxTreas);
                    fflush(stdout);
                    maxTreasure = (float) maxTreas;
                    break;

                default:
                    puts("Unexpected argument count.");
                    fflush(stdout);
                    answer = false;
                    break;
            }//end of switch
        }//end of for loop on argument count
        puts("after reading arguments");
        fflush(stdout);

        //we'll want to read the file
        std::vector<Room> rooms;
        rooms.reserve(10);
        AdjMat adjMat(0, nullptr); // Junk parameters. They will be overwritten in readFile.
        std::cout << "Before read file" << std::endl;
        answer = readFile(filename, adjMat, rooms); // read the file
        std::cout << "Back from read file" << std::endl;

        //we'll want to conduct the search
        //for the search we'll need an empty search history
        std::queue<SearchResults> history;
        //we'll need the Queue, into which we put rooms, and remove rooms
        std::queue<Room> searchQ;
        std::cout << "starting search" << std::endl;
        //we'll start searching with room 0
        bool done = false;
        int searchedRooms = 0;
        float foundTreasure = 0.0;
        Room &currRoom = rooms[0];
        //we set its searched field to true, and take its treasure
        currRoom.searched = true;
        foundTreasure += currRoom.treasure;
        //we record it in the history
        if ((currRoom.treasure <= maxTreasure) && (maxRooms > 0)) {
            //here we are enqueueing room 0 to prepare for initial loop
            std::cout << "Enqueuing room 0" << std::endl;
            searchQ.push(currRoom);
            history.push(SearchResults(0, currRoom.treasure));
        }

        while (!done) {   //here we want to find all of the rooms adjacent to the roomBeingSearched,
            //so we look in the adj matrix
            for (int col = 0; (col < rooms.size()) && !done; col++) {
                //we check whether this room is neighboring
                printf("checking rooms %d and %d.\n", currRoom.roomNumber, col);
                fflush(stdout);
                if (adjMat.getEdge(currRoom.roomNumber, col) == 1) {
                    puts("found an edge");
                    fflush(stdout);
                    //if so, we check whether room has been searched
                    if (!(rooms[col].searched)) {//if it hasn't been searched
                        printf("Room %d hasn't already been searched.\n", col);
                        //we set it to searched
                        rooms[col].searched = true;
                        if (foundTreasure < maxTreasure && searchedRooms < maxRooms)
                            //we check whether we can take the treasure vs. limit
                            //we check whether we've hit the room limit
                        {//we enqueue it for search
                            foundTreasure += rooms[col].treasure;
                            searchedRooms++;
                            std::cout << "found treasure updated to " << foundTreasure << "." << std::endl
                                      << "enqueuing room " << col << "." << std::endl
                                      << "Before enqueuing queue empty reports " << searchQ.empty() << std::endl;
                            searchQ.push(rooms[col]);
                            history.push(SearchResults(rooms[col].roomNumber, rooms[col].treasure));
                            std::cout << "After enqueuing, queue empty reports " << searchQ.empty() << std::endl;
                        }//check about search limits
                    }//room can still be searched
                }//room is a neighbor

                if (foundTreasure >= maxTreasure) {
                    done = true;
                    puts("Done by treasure");
                }
                if (searchedRooms >= maxRooms) {
                    done = true;
                    puts("Done by rooms");
                }
            }//scan for all possible rooms to search from this room
            //time to get the next room
            if (searchQ.empty()) {
                done = true;
                puts("Done by queue empty");
            }
            if (!done) {
                std::cout << "Invoking  dequeue" << std::endl;
                currRoom = searchQ.front();
                searchQ.pop();
            }
        }//while search is not done

        //search is now done, time to print the history
        int room;
        float treasureSubtotal = 0;
        std::ofstream output;
        output.open("output.txt");
        while (!history.empty()) {
            room = history.front().roomNumber;
            treasureSubtotal += history.front().treasure;
            printf("The room was %d, and the treasure subtotal was %f.\n", room, treasureSubtotal);
            output << room << " " << treasureSubtotal << std::endl;
            history.pop();
        }
        output.close();
    }//end of else we have good arguments

    return answer;
}

bool Production::readFile(char *filename, AdjMat &adjMat, std::vector<Room> &rooms) {
    bool ok = false;
    //the file tells how many rooms there are
    FILE *fp = fopen(filename, "r"); //read the file

    if (fp == nullptr) {
        puts("Error! opening file");
    } else {
        int nrooms;
        fscanf(fp, "%d", &nrooms);
        adjMat = AdjMat(nrooms, (int *) malloc(nrooms * nrooms * sizeof(int)));
        for (int roomr = 1; roomr < nrooms; roomr++) {
            std::cout << "on row " << roomr << std::endl;
            for (int roomc = 0; roomc < roomr; roomc++) {
                int temp = -1;
                fscanf(fp, "%d", &temp);
                std::cout << "in column " << roomc << ", read " << temp << std::endl;
                //now set the value in the adjacency matrix
                if (temp == 1) {
                    adjMat.setEdge(roomr, roomc);
                }
            }
        }

        for (int roomr = 0; roomr < nrooms; roomr++) {
            float tempTreas = 2.9;
            fscanf(fp, "%f", &tempTreas);
            rooms.emplace_back(roomr, tempTreas);
            printf("The treasure in room %d is %f\n", roomr, rooms[roomr].treasure);
        }
        ok = true;
    }
    fclose(fp);

    return ok;
}
